﻿// Example of demo-unity application for MEDUSA 2.0.
//     > (Last edit)
//     > 24/03/2022
//     > Author: Víctor Martínez-Cagigal

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using UnityEngine;
using UnityEngine.UI;
using System.Reflection;
using System.Runtime.InteropServices;

public class Manager : MonoBehaviour
{
    // Public parameters
    public string IP = "127.0.0.1";     // Overrided when calling the .exe with parameters
    public int port = 50000;

    // MEDUSA RUN STATES
    const int RUN_STATE_READY = 0;           // READY
    const int RUN_STATE_RUNNING = 1;         // RUNNING
    const int RUN_STATE_PAUSED = 2;          // PAUSED
    const int RUN_STATE_STOP = 3;            // TRANSITORY STATE WHILE USER PRESS THE STOP BUTTON AND MEDUSA IS READY TO START A NEW RUN AGAIN
    const int RUN_STATE_FINISHED = 4;        // THE RUN IS STILL ACTIVE, BUT FINISHED

    // Inner states
    const int STATE_WAITING_CONNECTION = -2;    // states of "state"
    const int STATE_WAITING_PARAMS = -1;
    const int STATE_CLOSING_TEXT = 27;          // states of "closingstate" of closingApplication()
    const int STATE_CLOSING_FINAL = 28;
    const int STATE_EVERYTHING_CLOSED = 29;

    // State controllers and coroutines
    static int state = STATE_WAITING_CONNECTION;
    static int closingstate = STATE_CLOSING_TEXT;
    static bool mustClose = false;
    static bool mustUpdateSamples = false;

    // FPS counter
    public float fpsResolution = 60;    // Screen refresh rate (frequency bin, resolution) in Hz
    private float updateCount = 0;
    private float fixedUpdateCount = 0;
    private float updateUpdateCountPerSecond;
    private float updateFixedUpdateCountPerSecond;

    // Other attributes
    public int updates_per_min = 0;
    public int no_samples = 0;
    private Vector2 lastScreenSize;
    public float tFinishText = 1.00f; // Time to display the closing text before closing Unity
    private GameObject fpsMonitorText, informationBox, informationText, counterText;

    // Colors
    public Color32 defaultBoxColor = new Color32(255, 255, 255, 255);
    public Color32 highlightBoxColor = new Color32(75, 75, 75, 255);

    // TCP client
    private MedusaTCPClient tcpClient;

    // Message Interpreter
    private MessageInterpreter.ParameterDecoder parameters = null;
    private MessageInterpreter messageInterpreter = new MessageInterpreter();

    /* ----------------------------------- UNITY LIFE-CYCLE FUNCTIONS ------------------------------------ */

    void Awake()
    {

        if (!Application.isEditor)
        {
            // Take the IP and port from the arguments
            // Usage: c-VEP Speller.exe 127.0.0.1 50000
            string[] arguments = Environment.GetCommandLineArgs();
            IP = arguments[1];
            port = Int32.Parse(arguments[2]);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        // Start the TCP/IP server
        tcpClient = new MedusaTCPClient(this, IPAddress.Parse(IP), port);
        tcpClient.Start();

        // FPS monitoring
        fpsMonitorText = GameObject.Find("FPSmonitor");
        StartCoroutine(monitorFPS());

        // Information texts and box
        informationBox = GameObject.Find("InformationBox");
        informationText = GameObject.Find("InformationText");
        counterText = GameObject.Find("CounterText");

        // WAIT until parameters are received!
        state = STATE_WAITING_CONNECTION;
    }

    // Show the FPS monitoring: current FPS and refresh rate
    void OnGUI()
    {
        fpsMonitorText.GetComponent<Text>().text = updateUpdateCountPerSecond.ToString() + " fps (@" + updateFixedUpdateCountPerSecond.ToString() + ")";
        if (updateFixedUpdateCountPerSecond < fpsResolution)
        {
            fpsMonitorText.GetComponent<Text>().color = Color.red;
        }
        else
        {
            fpsMonitorText.GetComponent<Text>().color = Color.green;
        }
    }

    // This function quits the current application by stopping the TCP client and closing the window
    public void quitApplication()
    {
        if (tcpClient.socketConnection != null)
        {
            bool tcpClosed = tcpClient.Stop();
            if (tcpClosed)
            {
                Debug.Log("> MedusaTCPClient closed successfully!");
            }
        }
        Application.Quit();
    }

    // This function starts the closing coroutine form the MainThread in Update()
    public void quitApplicationFromException()
    {
        mustClose = true;
    }


    /* ------------------------------------- UPDATE THINGS -------------------------------------- */

    // Update call (FPS may vary)
    void Update()
    {
        updateCount += 1;

        /* MINIMUM RESOLUTION */
        if (Screen.width < 450 || Screen.height < 450)
        {
            Screen.SetResolution(450, 450, false);
        }

        /* BEHAVIOR FOR DIFFERENT STATES (MAIN THREAD) */
        // If the TCP client just connected, request the parameters
        if (state == STATE_WAITING_CONNECTION && tcpClient.isConnected())
        {
            state = STATE_WAITING_PARAMS;
            // If the connection have been just established, send the waiting flag
            ServerMessage sm = new ServerMessage("waiting");
            tcpClient.SendMessage(sm.ToJson());
        }

        // If we are waiting the parameters
        if (state == STATE_WAITING_PARAMS)
        {
            // If parameters have been already received, execute this in the main thread
            if (parameters != null)
            {
                onParametersReady();
            }
        }

        // If the Unity app is stopping (closing)
        if (state == RUN_STATE_STOP)
        {
            if (closingstate == STATE_CLOSING_TEXT)
            {
                setInformationText("Closing...");
                setCounterText("");
            }
            if (closingstate == STATE_CLOSING_FINAL)
            {
                quitApplication();
                closingstate = STATE_EVERYTHING_CLOSED;
            }
        }

        /* EXECUTING CO-ROUTINES*/

        // If we must update the number of samples in the GUI
        if (mustUpdateSamples)
        {
            setInformationText("Running...");
            setCounterText("EEG samples: " + no_samples.ToString());
            mustUpdateSamples = false;
        }

        // If the TCPServer must close
        if (mustClose)
        {
            if (tcpClient.socketConnection != null)
            {
                // Send the confirmation that the Unity's client is going to close
                ServerMessage sm = new ServerMessage("close");
                tcpClient.SendMessage(sm.ToJson());
            }

            // Close the application
            mustClose = false;         // Avoid sending it twice
            StartCoroutine(closingApplication());
        }
    }

    // Fixed update at the rate controlled by 'updates_per_min'
    void FixedUpdate()
    {
        fixedUpdateCount += 1;

        // Update the counter
        if (state == RUN_STATE_RUNNING)
        {
            // Request the number of EEG samples to MEDUSA
            ServerMessage sm = new ServerMessage("request_samples");
            sm.addValue("dummy", "value");      // Example for adding more attributes to the message (not used)
            tcpClient.SendMessage(sm.ToJson());
        }

    }



    // This function sets the information text. IMPORTANT: only the main thread is allowed to run this function.
    void setInformationText(string infoMsg)
    {
        if (string.IsNullOrEmpty(infoMsg))
        {
            informationBox.SetActive(false);
            informationText.SetActive(false);
        }
        else
        {
            informationBox.SetActive(true);
            informationText.SetActive(true);
            informationText.GetComponent<Text>().text = infoMsg;
        }
    }

    // This function sets the counter text. IMPORTANT: only the main thread is allowed to run this function.
    void setCounterText(string infoMsg)
    {
        if (string.IsNullOrEmpty(infoMsg))
        {
            counterText.SetActive(false);
        }
        else
        {
            counterText.SetActive(true);
            counterText.GetComponent<Text>().text = infoMsg;
        }
    }

    /* ------------------------------------------- COMMUNICATION ------------------------------------------- */

    // This function is called by the MedusaTCPClient whenever a packet is received in order to interpret it
    public void interpretMessage(string message)
    {
        Debug.Log("Received from server: " + message);
        string eventType = messageInterpreter.decodeEventType(message);
        switch (eventType)
        {
            case "play":
                if (state != STATE_WAITING_PARAMS)
                {
                    state = RUN_STATE_RUNNING;
                }
                break;
            case "pause":
                if (state != STATE_WAITING_PARAMS)
                {
                    state = RUN_STATE_PAUSED;
                    setInformationText("Paused");
                }
                break;
            case "resume":
                if (state != STATE_WAITING_PARAMS)
                {
                    state = RUN_STATE_RUNNING;
                }
                break;
            case "stop":
                if (state != STATE_WAITING_PARAMS)
                {
                    state = RUN_STATE_STOP;
                    mustClose = true;       // Update() will recognize it and start a coroutine
                }
                break;
            case "setParameters":
                // The main thread will detect that parameters are here using Update() and will call onParametersReady() itself
                parameters = messageInterpreter.decodeParameters(message);
                Debug.Log("Parameters received.");
                break;
            case "samplesUpdate":
                // We have received an update of the number of EEG samples from MEDUSA, we must notify the main thread to update the GUI
                mustUpdateSamples = true;
                no_samples = messageInterpreter.decodeSamples(message);
                break;
            case "exception":
                string exception = messageInterpreter.decodeException(message);
                Debug.LogError("Exception from client, aborting: " + exception);
                state = RUN_STATE_STOP;

                tcpClient.socketConnection.Close();
                tcpClient.socketConnection = null;
                mustClose = true;
                break;
            default:
                Debug.LogError("Unknown action!");
                break;
        }
    }

    // This function is called by the main thread when parameters are ready
    void onParametersReady()
    {
        // Extract the parameters
        updates_per_min = parameters.updates_per_min;

        // Set up the fixedDeltaTime to the desired frame rate for the clock
        Application.targetFrameRate = -1;
        Time.fixedDeltaTime = ((float)60 / updates_per_min); // in seconds

        // Change state
        state = RUN_STATE_READY;
        ServerMessage sm = new ServerMessage("ready");
        tcpClient.SendMessage(sm.ToJson());
        setInformationText("Waiting to start...");
        setCounterText("");
    }

    /* ------------------------------------------- CO-ROUTINES ------------------------------------------- */

    // This thread controls the FPS rate
    IEnumerator monitorFPS()
    {
        while (true)
        {
            yield return new WaitForSeconds(1);
            updateUpdateCountPerSecond = updateCount;
            updateFixedUpdateCountPerSecond = fixedUpdateCount;

            updateCount = 0;
            fixedUpdateCount = 0;
        }
    }

    // This thread controls the timings for closing the application.
    IEnumerator closingApplication()
    {
        Debug.Log("Closing...");
        closingstate = STATE_CLOSING_TEXT;
        yield return new WaitForSeconds((float)tFinishText);

        closingstate = STATE_CLOSING_FINAL;
    }

}

